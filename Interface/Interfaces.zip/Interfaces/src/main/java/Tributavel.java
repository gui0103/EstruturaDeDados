public interface Tributavel {

    public Double getValortributo();
}
